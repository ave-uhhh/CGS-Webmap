document.addEventListener("DOMContentLoaded", function () {
    const dropdownHeaders = document.querySelectorAll('.dropdown-header');

    dropdownHeaders.forEach(header => {
        header.addEventListener('click', () => {
            const content = header.nextElementSibling; // 获取下拉菜单内容
            const triangle = header.querySelector('span'); // 获取下拉箭头

            // 切换显示状态
            content.style.display = content.style.display === 'block' ? 'none' : 'block';

            // 切换箭头方向
            triangle.classList.toggle('open');
        });
    });

    // 获取当前页面的路径
    const currentPath = window.location.pathname;

    // 遍历所有的菜单项，如果匹配当前页面路径则添加 active 类
    const menuLinks = document.querySelectorAll('nav a');
    menuLinks.forEach(link => {
        if (link.getAttribute('href') === currentPath) {
            link.classList.add('active-link');
        }
    });
});
