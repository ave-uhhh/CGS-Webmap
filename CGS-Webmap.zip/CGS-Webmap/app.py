from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def homepage():
    return render_template('homepage.html')

@app.route('/our_study')
def our_study():
    return render_template('our_study.html')

@app.route('/methodology')
def methodology():
    return render_template('methodology.html')

@app.route('/findings')
def findings():
    return render_template('findings.html')

@app.route('/map')
def map_page():
    return render_template('map.html')

@app.route('/about')
def about():
    return render_template('about.html')

if __name__ == '__main__':
    app.run(debug=True)
